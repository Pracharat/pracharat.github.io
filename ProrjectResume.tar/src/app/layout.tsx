import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Pracharat Sungtong — Fullstack Developer",
  description:
    "Computer Engineering professional with expertise in Software Development (Node.js, React, Angular) and IT Infrastructure Management.",
  keywords: [
    "Pracharat Sungtong",
    "Fullstack Developer",
    "Next.js",
    "React",
    "Node.js",
    "Tailwind CSS",
    "Software Engineer",
  ],
  authors: [{ name: "Pracharat Sungtong" }],
  openGraph: {
    title: "Pracharat Sungtong — Fullstack Developer",
    description:
      "Software Development & IT Operations — Building high-performance web solutions.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}