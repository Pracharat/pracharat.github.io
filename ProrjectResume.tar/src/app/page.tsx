"use client";

import { motion } from "framer-motion";
import {
  Mail,
  Phone,
  MessageCircle,
  MapPin,
  Code2,
  Server,
  MonitorSmartphone,
  ChevronRight,
  ExternalLink,
  GraduationCap,
  Briefcase,
  Cpu,
  Globe,
  Shield,
  Zap,
} from "lucide-react";

/* ─── resume data ─── */
const data = {
  name: "PRACHARAT SUNGTONG",
  title: "Fullstack Developer",
  tagline:
    "Software Engineering & IT Operations — Building high-performance, pixel-perfect web solutions.",
  about:
    "A driven Computer Engineering professional with a unique blend of experience in Software Development and IT Infrastructure Management. Proven ability to adapt quickly, whether designing secure backend APIs or troubleshooting complex system and network failures. Actively seeking opportunities to build, test, and optimize high-quality technology solutions.",
  contact: {
    email: "Pracharat.sung@gmail.com",
    phone: "080-2924312",
    line: "Pracharat222",
    location: "Thailand",
  },
  skills: {
    development: ["JavaScript", "Node.js", "React.js", "Angular", "REST API", "MongoDB", "MSSQL", "TypeScript"],
    operations: ["Network Admin", "IT Support", "Troubleshooting", "System Management", "LAN / Wi-Fi", "Helpdesk"],
  },
  experience: [
    {
      role: "IT Supervisor",
      company: "TEETH TALK CO., LTD.",
      period: "2026 — Present",
      description:
        "Oversee and maintain internal IT infrastructure including computers, printers, and office equipment. Manage software installations, operating systems, and company-specific applications. Monitor and maintain LAN, Internet, and Wi-Fi networks with proactive troubleshooting.",
      icon: MonitorSmartphone,
    },
    {
      role: "IT Support",
      company: "Prachuapkhirikhan Provincial Cooperative Auditing Office",
      period: "2022 — 2026",
      description:
        "Provided troubleshooting and technical support to staff for hardware and software issues. Managed IT equipment lifecycle from onboarding to offboarding, including device setup and system access provisioning.",
      icon: Shield,
    },
    {
      role: "Backend Developer",
      company: "Dplus Intertrade Co., Ltd.",
      period: "2020 — 2021",
      description:
        "Designed and implemented backend services and APIs using Node.js, React, and Angular. Optimized system performance, security, and scalability. Participated in requirement analysis and provided software consulting.",
      icon: Server,
    },
  ],
  education: [
    {
      degree: "Bachelor of Engineering",
      field: "Computer Engineering",
      school: "Rajamangala University of Technology Thanyaburi",
      period: "2016 — 2020",
      gpa: "2.93",
    },
    {
      degree: "Higher Vocational Certificate",
      field: "Electronic Industry",
      school: "Prachuap Khiri Khan Technical College",
      period: "2014 — 2016",
      gpa: "3.70",
    },
    {
      degree: "Vocational Certificate",
      field: "Electronic",
      school: "Prachuap Khiri Khan Technical College",
      period: "2011 — 2014",
      gpa: "3.35",
    },
  ],
};

/* ─── animation helpers ─── */
const fadeUp = (i: number) => ({
  initial: { opacity: 0, y: 30 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-60px" },
  transition: { duration: 0.5, delay: i * 0.1, ease: "easeOut" },
});

/* ─── main page ─── */
export default function Home() {
  return (
    <div className="min-h-screen grid-bg relative overflow-x-hidden">
      {/* ── ambient glow orbs ── */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 h-[600px] w-[600px] rounded-full bg-blue-500/5 blur-[120px]" />
        <div className="absolute top-1/2 -left-40 h-[500px] w-[500px] rounded-full bg-cyan-500/5 blur-[120px]" />
        <div className="absolute -bottom-40 right-1/3 h-[400px] w-[400px] rounded-full bg-blue-600/5 blur-[100px]" />
      </div>

      <main className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {/* ══════════ HERO ══════════ */}
        <section className="min-h-screen flex items-center pt-20">
          <div className="grid lg:grid-cols-5 gap-10 lg:gap-16 items-center w-full">
            {/* text */}
            <motion.div
              className="lg:col-span-3 space-y-6"
              initial={{ opacity: 0, x: -40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, ease: "easeOut" }}
            >
              <motion.div
                className="inline-flex items-center gap-2 rounded-full border border-blue-500/20 bg-blue-500/5 px-4 py-1.5 text-xs font-mono text-cyan-400 tracking-wider uppercase"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.5 }}
              >
                <Cpu className="h-3.5 w-3.5" />
                Strategy &amp; Blueprint
              </motion.div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight leading-tight">
                <span className="text-glow-blue text-white">{data.name}</span>
              </h1>

              <h2 className="text-xl sm:text-2xl font-medium text-cyan-400 text-glow-cyan">
                {data.title}
              </h2>

              <div className="h-px w-24 bg-gradient-to-r from-blue-500 to-cyan-500" />

              <p className="text-base sm:text-lg text-muted-foreground leading-relaxed max-w-xl">
                {data.tagline}
              </p>

              {/* contact row */}
              <div className="flex flex-wrap gap-4 pt-2 text-sm text-muted-foreground">
                <a
                  href={`mailto:${data.contact.email}`}
                  className="inline-flex items-center gap-2 rounded-lg border border-border bg-card/50 px-4 py-2 transition-all hover:border-blue-500/40 hover:bg-blue-500/5 hover:text-blue-400"
                >
                  <Mail className="h-4 w-4" />
                  <span className="hidden sm:inline">{data.contact.email}</span>
                </a>
                <a
                  href={`tel:${data.contact.phone}`}
                  className="inline-flex items-center gap-2 rounded-lg border border-border bg-card/50 px-4 py-2 transition-all hover:border-cyan-500/40 hover:bg-cyan-500/5 hover:text-cyan-400"
                >
                  <Phone className="h-4 w-4" />
                  <span className="hidden sm:inline">{data.contact.phone}</span>
                </a>
                <span className="inline-flex items-center gap-2 rounded-lg border border-border bg-card/50 px-4 py-2">
                  <MessageCircle className="h-4 w-4 text-green-400" />
                  <span className="hidden sm:inline">LINE: {data.contact.line}</span>
                </span>
              </div>

              {/* scroll hint */}
              <motion.div
                className="pt-8 flex items-center gap-2 text-xs text-muted-foreground/60 font-mono"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.2, duration: 0.8 }}
              >
                <span>SCROLL</span>
                <motion.div
                  animate={{ y: [0, 6, 0] }}
                  transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
                >
                  <ChevronRight className="h-3.5 w-3.5 rotate-90" />
                </motion.div>
              </motion.div>
            </motion.div>

            {/* photo */}
            <motion.div
              className="lg:col-span-2 flex justify-center"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4, duration: 0.6, ease: "easeOut" }}
            >
              <div className="relative group">
                <div className="absolute -inset-1 rounded-2xl bg-gradient-to-br from-blue-500/30 via-cyan-500/20 to-blue-600/30 blur-md group-hover:blur-lg transition-all duration-500" />
                <div className="relative rounded-2xl overflow-hidden border border-blue-500/20 animate-pulse-glow">
                  <img
                    src="/photo.jpg"
                    alt="Pracharat Sungtong"
                    className="w-64 h-80 sm:w-72 sm:h-96 object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#050816] via-transparent to-transparent" />
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* ══════════ ABOUT ══════════ */}
        <section className="py-20">
          <motion.div {...fadeUp(0)} className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="h-px flex-1 max-w-[60px] bg-gradient-to-r from-blue-500 to-cyan-500" />
              <h2 className="text-xs font-mono text-cyan-400 tracking-widest uppercase">
                About Me
              </h2>
            </div>
            <p className="text-base sm:text-lg text-muted-foreground leading-relaxed max-w-3xl">
              {data.about}
            </p>
          </motion.div>
        </section>

        {/* ══════════ SKILLS ══════════ */}
        <section className="py-20">
          <motion.div {...fadeUp(0)} className="space-y-10">
            <div className="flex items-center gap-3">
              <div className="h-px flex-1 max-w-[60px] bg-gradient-to-r from-blue-500 to-cyan-500" />
              <h2 className="text-xs font-mono text-cyan-400 tracking-widest uppercase">
                Skills &amp; Expertise
              </h2>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {/* Software Dev */}
              <motion.div
                {...fadeUp(1)}
                className="cyber-border rounded-xl bg-card/80 backdrop-blur-sm p-6 space-y-5"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-500/10 border border-blue-500/20">
                    <Code2 className="h-5 w-5 text-blue-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-white">
                    Software Development
                  </h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {data.skills.development.map((skill) => (
                    <span
                      key={skill}
                      className="rounded-full border border-blue-500/20 bg-blue-500/5 px-3 py-1 text-sm font-mono text-blue-300 transition-colors hover:bg-blue-500/10 hover:border-blue-500/40"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </motion.div>

              {/* IT Ops */}
              <motion.div
                {...fadeUp(2)}
                className="cyber-border rounded-xl bg-card/80 backdrop-blur-sm p-6 space-y-5"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-500/10 border border-cyan-500/20">
                    <Globe className="h-5 w-5 text-cyan-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-white">
                    IT Operations
                  </h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {data.skills.operations.map((skill) => (
                    <span
                      key={skill}
                      className="rounded-full border border-cyan-500/20 bg-cyan-500/5 px-3 py-1 text-sm font-mono text-cyan-300 transition-colors hover:bg-cyan-500/10 hover:border-cyan-500/40"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </motion.div>
            </div>
          </motion.div>
        </section>

        {/* ══════════ EXPERIENCE ══════════ */}
        <section className="py-20">
          <motion.div {...fadeUp(0)} className="space-y-10">
            <div className="flex items-center gap-3">
              <div className="h-px flex-1 max-w-[60px] bg-gradient-to-r from-blue-500 to-cyan-500" />
              <h2 className="text-xs font-mono text-cyan-400 tracking-widest uppercase">
                Experience
              </h2>
            </div>

            <div className="space-y-6">
              {data.experience.map((exp, i) => {
                const Icon = exp.icon;
                return (
                  <motion.div
                    key={exp.company}
                    {...fadeUp(i + 1)}
                    className="cyber-border rounded-xl bg-card/80 backdrop-blur-sm p-6 sm:p-8 group"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start gap-4 sm:gap-6">
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-blue-500/10 border border-blue-500/20 group-hover:bg-blue-500/20 transition-colors">
                        <Icon className="h-6 w-6 text-blue-400" />
                      </div>
                      <div className="flex-1 space-y-3 min-w-0">
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 sm:gap-4">
                          <div>
                            <h3 className="text-lg font-semibold text-white">
                              {exp.role}
                            </h3>
                            <p className="text-sm text-blue-400 font-medium">
                              {exp.company}
                            </p>
                          </div>
                          <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary/50 px-3 py-1 text-xs font-mono text-muted-foreground whitespace-nowrap self-start">
                            <Briefcase className="h-3 w-3" />
                            {exp.period}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {exp.description}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        </section>

        {/* ══════════ EDUCATION ══════════ */}
        <section className="py-20">
          <motion.div {...fadeUp(0)} className="space-y-10">
            <div className="flex items-center gap-3">
              <div className="h-px flex-1 max-w-[60px] bg-gradient-to-r from-blue-500 to-cyan-500" />
              <h2 className="text-xs font-mono text-cyan-400 tracking-widest uppercase">
                Education
              </h2>
            </div>

            <div className="grid sm:grid-cols-3 gap-5">
              {data.education.map((edu, i) => (
                <motion.div
                  key={edu.school + edu.period}
                  {...fadeUp(i + 1)}
                  className="cyber-border rounded-xl bg-card/80 backdrop-blur-sm p-6 space-y-4 group hover:border-blue-500/30 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-500/10 border border-cyan-500/20 group-hover:bg-cyan-500/20 transition-colors">
                      <GraduationCap className="h-5 w-5 text-cyan-400" />
                    </div>
                    <span className="text-2xl font-bold font-mono text-blue-400">
                      {edu.gpa}
                    </span>
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white">
                      {edu.degree}
                    </h3>
                    <p className="text-xs text-cyan-400 mt-0.5">{edu.field}</p>
                  </div>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <p>{edu.school}</p>
                    <p className="font-mono">{edu.period}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </section>

        {/* ══════════ TECH STACK ══════════ */}
        <section className="py-20">
          <motion.div {...fadeUp(0)} className="space-y-10">
            <div className="flex items-center gap-3">
              <div className="h-px flex-1 max-w-[60px] bg-gradient-to-r from-blue-500 to-cyan-500" />
              <h2 className="text-xs font-mono text-cyan-400 tracking-widest uppercase">
                Tech Stack
              </h2>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
              {[
                { name: "Next.js", icon: Zap, desc: "React Framework" },
                { name: "Tailwind", icon: Code2, desc: "Utility-First CSS" },
                { name: "React", icon: Globe, desc: "UI Library" },
                { name: "Node.js", icon: Server, desc: "Runtime" },
                { name: "TypeScript", icon: Code2, desc: "Type Safety" },
                { name: "MongoDB", icon: Shield, desc: "NoSQL Database" },
              ].map((tech, i) => {
                const Icon = tech.icon;
                return (
                  <motion.div
                    key={tech.name}
                    {...fadeUp(i + 1)}
                    className="cyber-border rounded-xl bg-card/80 backdrop-blur-sm p-4 flex flex-col items-center text-center gap-2 group hover:border-blue-500/30 transition-all"
                  >
                    <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-blue-500/10 border border-blue-500/20 group-hover:bg-blue-500/15 transition-colors">
                      <Icon className="h-5 w-5 text-blue-400" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white font-mono">
                        {tech.name}
                      </p>
                      <p className="text-[11px] text-muted-foreground mt-0.5">
                        {tech.desc}
                      </p>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        </section>

        {/* ══════════ CONTACT / FOOTER ══════════ */}
        <footer className="pt-10 pb-8 border-t border-border">
          <motion.div
            {...fadeUp(0)}
            className="flex flex-col sm:flex-row items-center justify-between gap-6"
          >
            <div className="text-center sm:text-left space-y-1">
              <p className="text-sm font-semibold text-white">
                {data.name}
              </p>
              <p className="text-xs text-muted-foreground font-mono">
                {data.title}
              </p>
            </div>

            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <a
                href={`mailto:${data.contact.email}`}
                className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 transition-all hover:border-blue-500/40 hover:text-blue-400"
              >
                <Mail className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">{data.contact.email}</span>
                <span className="sm:hidden">Email</span>
              </a>
              <a
                href={`tel:${data.contact.phone}`}
                className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 transition-all hover:border-cyan-500/40 hover:text-cyan-400"
              >
                <Phone className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">{data.contact.phone}</span>
                <span className="sm:hidden">Phone</span>
              </a>
              <span className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-2">
                <MapPin className="h-3.5 w-3.5 text-cyan-400" />
                <span>{data.contact.location}</span>
              </span>
            </div>
          </motion.div>

          <p className="mt-8 text-center text-[11px] text-muted-foreground/50 font-mono">
            Built with Next.js + Tailwind CSS &middot; 2026
          </p>
        </footer>
      </main>
    </div>
  );
}